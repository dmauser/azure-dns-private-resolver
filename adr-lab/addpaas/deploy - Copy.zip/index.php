<?php
print gmdate("Y-m-d\TH:i:s\Z");
echo $variable1 ." ". $variable2;
print $_SERVER['REMOTE_ADDR'];
echo $variable1 ." ". $variable2;
print $_SERVER['REMOTE_PORT']
?>