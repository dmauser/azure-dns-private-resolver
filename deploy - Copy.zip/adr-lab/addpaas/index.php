<!DOCTYPE html>
<html>
<body>

<?php
echo gmdate("Y-m-d\TH:i:s\Z");
echo $_SERVER['REMOTE_ADDR'];
echo $_SERVER['REMOTE_PORT'];
?>

</body>
</html>